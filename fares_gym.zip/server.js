﻿const express = require("express");
const cors = require("cors");
const multer = require("multer");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// Ensure directories exist
const dataDir = path.join(__dirname, "data");
const uploadsDir = path.join(__dirname, "uploads");
const dbPath = path.join(dataDir, "subscribers.json");

if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, "[]", "utf-8");

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use("/uploads", express.static(uploadsDir));
app.use(express.static(path.join(__dirname, "public")));

// Multer Storage Configuration
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadsDir);
  },
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname).toLowerCase() || ".png";
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, "avatar-" + uniqueSuffix + ext);
  },
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith("image/")) {
      cb(null, true);
    } else {
      cb(new Error("Only image files are allowed!"), false);
    }
  },
});

// Database helper functions
function readDatabase() {
  try {
    const raw = fs.readFileSync(dbPath, "utf-8");
    return JSON.parse(raw);
  } catch (err) {
    console.error("Error reading database:", err);
    return [];
  }
}

function writeDatabase(data) {
  try {
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2), "utf-8");
    return true;
  } catch (err) {
    console.error("Error writing database:", err);
    return false;
  }
}

// Server-Sent Events (SSE) for Real-Time Sync across all clients
let clients = [];

app.get("/api/events", (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.flushHeaders();

  const clientId = Date.now();
  clients.push({ id: clientId, res });

  // Send initial ping
  res.write(`data: ${JSON.stringify({ type: "connected", clientId })}\n\n`);

  req.on("close", () => {
    clients = clients.filter((c) => c.id !== clientId);
  });
});

function broadcast(action, payload) {
  const data = JSON.stringify({ action, payload, timestamp: new Date().toISOString() });
  clients.forEach((c) => {
    try {
      c.res.write(`data: ${data}\n\n`);
    } catch (e) {
      // client disconnected
    }
  });
}

// Date helper: add exactly N days
function addDays(dateStr, days) {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + days);
  return d.toISOString().split("T")[0];
}

// Status calculator
function getSubscriptionStatus(endDateStr) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const end = new Date(endDateStr);
  end.setHours(0, 0, 0, 0);

  const diffTime = end.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays > 3) {
    return { status: "active", color: "green", daysLeft: diffDays };
  } else if (diffDays >= 0 && diffDays <= 3) {
    return { status: "expiring", color: "yellow", daysLeft: diffDays };
  } else {
    return { status: "expired", color: "red", daysLeft: diffDays, overdueDays: Math.abs(diffDays) };
  }
}

// API Routes

// 1. GET /api/subscribers
app.get("/api/subscribers", (req, res) => {
  const subscribers = readDatabase();
  const enhanced = subscribers.map((sub) => ({
    ...sub,
    statusInfo: getSubscriptionStatus(sub.endDate),
  }));
  res.json({ success: true, count: enhanced.length, data: enhanced });
});

// 2. GET /api/stats
app.get("/api/stats", (req, res) => {
  const subscribers = readDatabase();
  let total = subscribers.length;
  let active = 0;
  let expiring = 0;
  let expired = 0;

  subscribers.forEach((sub) => {
    const st = getSubscriptionStatus(sub.endDate);
    if (st.status === "active") active++;
    else if (st.status === "expiring") expiring++;
    else if (st.status === "expired") expired++;
  });

  res.json({
    success: true,
    data: { total, active, expiring, expired },
  });
});

// 3. POST /api/subscribers - Add Member
app.post("/api/subscribers", upload.single("photo"), (req, res) => {
  try {
    const { fullName, phone, plan, price, startDate, endDate } = req.body;

    if (!fullName || !fullName.trim()) {
      return res.status(400).json({ success: false, message: "Full Name is required" });
    }

    const todayStr = new Date().toISOString().split("T")[0];
    const subStartDate = startDate || todayStr;
    const subEndDate = endDate || addDays(subStartDate, 30);

    let photoUrl = "";
    if (req.file) {
      photoUrl = `/uploads/${req.file.filename}`;
    }

    const newSubscriber = {
      id: "sub_" + Date.now() + "_" + Math.random().toString(36).substring(2, 7),
      fullName: fullName.trim(),
      phone: phone ? phone.trim() : "",
      plan: plan ? plan.trim() : "اشتراك شهري (Abonnement Mensuel)",
      price: price ? price.trim() : "3000 DZD",
      photo: photoUrl,
      startDate: subStartDate,
      endDate: subEndDate,
      createdAt: new Date().toISOString(),
    };

    const subscribers = readDatabase();
    subscribers.unshift(newSubscriber);
    writeDatabase(subscribers);

    const result = {
      ...newSubscriber,
      statusInfo: getSubscriptionStatus(newSubscriber.endDate),
    };

    broadcast("create", result);
    return res.status(201).json({ success: true, data: result });
  } catch (err) {
    console.error("Error adding subscriber:", err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// 4. PUT /api/subscribers/:id - Update Member
app.put("/api/subscribers/:id", upload.single("photo"), (req, res) => {
  try {
    const { id } = req.params;
    const { fullName, phone, plan, price, startDate, endDate } = req.body;
    const subscribers = readDatabase();
    const index = subscribers.findIndex((s) => s.id === id);

    if (index === -1) {
      return res.status(400).json({ success: false, message: "Subscriber not found" });
    }

    const existing = subscribers[index];

    let photoUrl = existing.photo;
    if (req.file) {
      // Remove old uploaded photo if it exists and is in uploads/
      if (existing.photo && existing.photo.startsWith("/uploads/")) {
        const oldPath = path.join(__dirname, existing.photo);
        if (fs.existsSync(oldPath)) {
          try { fs.unlinkSync(oldPath); } catch (e) {}
        }
      }
      photoUrl = `/uploads/${req.file.filename}`;
    }

    const updated = {
      ...existing,
      fullName: fullName ? fullName.trim() : existing.fullName,
      phone: phone !== undefined ? phone.trim() : existing.phone,
      plan: plan ? plan.trim() : existing.plan,
      price: price ? price.trim() : existing.price,
      startDate: startDate || existing.startDate,
      endDate: endDate || existing.endDate,
      photo: photoUrl,
      updatedAt: new Date().toISOString(),
    };

    subscribers[index] = updated;
    writeDatabase(subscribers);

    const result = {
      ...updated,
      statusInfo: getSubscriptionStatus(updated.endDate),
    };

    broadcast("update", result);
    return res.json({ success: true, data: result });
  } catch (err) {
    console.error("Error updating subscriber:", err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// 5. POST /api/subscribers/:id/renew - Renew +30 Days
app.post("/api/subscribers/:id/renew", (req, res) => {
  try {
    const { id } = req.params;
    const subscribers = readDatabase();
    const index = subscribers.findIndex((s) => s.id === id);

    if (index === -1) {
      return res.status(404).json({ success: false, message: "Subscriber not found" });
    }

    const sub = subscribers[index];
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const currentEnd = new Date(sub.endDate);
    currentEnd.setHours(0, 0, 0, 0);

    let newStart = sub.startDate;
    let newEnd = "";

    // If subscription is still active or expiring, extend from existing end date
    if (currentEnd >= today) {
      newEnd = addDays(sub.endDate, 30);
    } else {
      // If already expired, restart from today for 30 days
      const todayStr = new Date().toISOString().split("T")[0];
      newStart = todayStr;
      newEnd = addDays(todayStr, 30);
    }

    const updated = {
      ...sub,
      startDate: newStart,
      endDate: newEnd,
      renewedAt: new Date().toISOString(),
    };

    subscribers[index] = updated;
    writeDatabase(subscribers);

    const result = {
      ...updated,
      statusInfo: getSubscriptionStatus(updated.endDate),
    };

    broadcast("renew", result);
    return res.json({ success: true, data: result });
  } catch (err) {
    console.error("Error renewing subscriber:", err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// 6. DELETE /api/subscribers/:id - Delete Member
app.delete("/api/subscribers/:id", (req, res) => {
  try {
    const { id } = req.params;
    const subscribers = readDatabase();
    const index = subscribers.findIndex((s) => s.id === id);

    if (index === -1) {
      return res.status(404).json({ success: false, message: "Subscriber not found" });
    }

    const sub = subscribers[index];

    // Remove photo file if exists and not default
    if (sub.photo && sub.photo.startsWith("/uploads/")) {
      const p = path.join(__dirname, sub.photo);
      if (fs.existsSync(p)) {
        try { fs.unlinkSync(p); } catch (e) {}
      }
    }

    subscribers.splice(index, 1);
    writeDatabase(subscribers);

    broadcast("delete", { id });
    return res.json({ success: true, message: "Deleted successfully", id });
  } catch (err) {
    console.error("Error deleting subscriber:", err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// Fallback to index.html
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`====================================================`);
  console.log(`🚀 FARES GYM Admin Panel Server is running!`);
  console.log(`📍 Local access: http://localhost:${PORT}`);
  console.log(`🌐 Network access: http://0.0.0.0:${PORT}`);
  console.log(`⚡ Real-time SSE synchronization enabled.`);
  console.log(`====================================================`);
});
