﻿// ==========================================================================
// FARES GYM - Client Application Logic
// ==========================================================================

let currentLang = localStorage.getItem("fares_gym_lang") || "ar";
let subscribers = [];
let currentFilter = "all";
let searchQuery = "";
let selectedPhotoFile = null;
let deleteTargetId = null;

// Initialize app on DOM ready
document.addEventListener("DOMContentLoaded", () => {
  initLanguage();
  initDragAndDrop();
  loadSubscribers();
  initRealtimeSSE();
});

// --------------------------------------------------------------------------
// 1. Language & Internationalization (i18n)
// --------------------------------------------------------------------------
function initLanguage() {
  setLanguage(currentLang);
}

function toggleLanguage() {
  const newLang = currentLang === "ar" ? "fr" : "ar";
  setLanguage(newLang);
}

function setLanguage(lang) {
  currentLang = lang;
  localStorage.setItem("fares_gym_lang", lang);

  const html = document.documentElement;
  html.lang = lang;
  html.dir = lang === "ar" ? "rtl" : "ltr";

  // Switch button label
  const langBtnText = document.getElementById("lang-btn-text");
  if (langBtnText) {
    langBtnText.textContent = lang === "ar" ? "Français" : "العربية";
  }

  // Update static text elements with data-i18n
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    if (translations[lang] && translations[lang][key]) {
      el.textContent = translations[lang][key];
    }
  });

  // Update input placeholders
  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    const key = el.getAttribute("data-i18n-placeholder");
    if (translations[lang] && translations[lang][key]) {
      el.placeholder = translations[lang][key];
    }
  });

  // Re-render table & stats to refresh status labels in target language
  renderSubscribers();
  updateStats();
}

function t(key, params = {}) {
  let text = (translations[currentLang] && translations[currentLang][key]) || key;
  for (const [k, v] of Object.entries(params)) {
    text = text.replace(`{${k}}`, v);
  }
  return text;
}

// --------------------------------------------------------------------------
// 2. Real-Time SSE Listener (Live Updates from Server)
// --------------------------------------------------------------------------
function initRealtimeSSE() {
  const syncBadge = document.getElementById("sync-badge");
  const syncText = document.getElementById("sync-text");

  if (!window.EventSource) return;

  const eventSource = new EventSource("/api/events");

  eventSource.onopen = () => {
    if (syncBadge) syncBadge.classList.remove("opacity-50");
    if (syncText) syncText.textContent = t("liveConnected");
  };

  eventSource.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      if (data.action === "create" || data.action === "update" || data.action === "renew" || data.action === "delete") {
        // Silently reload data from server
        loadSubscribers(false);
      }
    } catch (e) {
      console.error("SSE parse error:", e);
    }
  };

  eventSource.onerror = () => {
    if (syncBadge) syncBadge.classList.add("opacity-50");
    if (syncText) syncText.textContent = t("liveDisconnected");
  };
}

// --------------------------------------------------------------------------
// 3. API Data Fetching & Sync
// --------------------------------------------------------------------------
async function loadSubscribers(showRefreshAnim = false) {
  const refreshIcon = document.getElementById("refresh-icon");
  if (showRefreshAnim && refreshIcon) refreshIcon.classList.add("fa-spin");

  try {
    const res = await fetch("/api/subscribers");
    const json = await res.json();
    if (json.success) {
      subscribers = json.data;
      renderSubscribers();
      updateStats();
    }
  } catch (err) {
    console.error("Failed to load subscribers:", err);
    showToast(t("toastError"), "error");
  } finally {
    if (showRefreshAnim && refreshIcon) {
      setTimeout(() => refreshIcon.classList.remove("fa-spin"), 500);
    }
  }
}

// --------------------------------------------------------------------------
// 4. Status Calculation & Formatting
// --------------------------------------------------------------------------
function calculateStatus(endDateStr) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const end = new Date(endDateStr);
  end.setHours(0, 0, 0, 0);

  const diffTime = end.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays > 3) {
    return {
      type: "active",
      badgeClass: "badge-active",
      label: t("statusActive"),
      daysText: t("daysRemaining", { n: diffDays }),
      daysCount: diffDays,
      color: "#10b981",
    };
  } else if (diffDays >= 0 && diffDays <= 3) {
    let daysLabel = "";
    if (diffDays === 0) daysLabel = t("todayExpires");
    else if (diffDays === 1) daysLabel = t("dayRemaining");
    else if (diffDays === 2 && currentLang === "ar") daysLabel = t("twoDaysRemaining");
    else daysLabel = t("daysRemaining", { n: diffDays });

    return {
      type: "expiring",
      badgeClass: "badge-expiring",
      label: t("statusExpiring"),
      daysText: daysLabel,
      daysCount: diffDays,
      color: "#f59e0b",
    };
  } else {
    const overdue = Math.abs(diffDays);
    return {
      type: "expired",
      badgeClass: "badge-expired",
      label: t("statusExpired"),
      daysText: t("daysOverdue", { n: overdue }),
      daysCount: diffDays,
      color: "#ef4444",
    };
  }
}

// Helper: Format Date for Display
function formatDate(dateStr) {
  if (!dateStr) return "-";
  const parts = dateStr.split("-");
  if (parts.length === 3) {
    return `${parts[2]}/${parts[1]}/${parts[0]}`; // DD/MM/YYYY
  }
  return dateStr;
}

// Helper: Add N days to date string (YYYY-MM-DD)
function addDays(dateStr, days = 30) {
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return "";
  d.setDate(d.getDate() + days);
  return d.toISOString().split("T")[0];
}

// --------------------------------------------------------------------------
// 5. Rendering Table & Mobile Cards
// --------------------------------------------------------------------------
function renderSubscribers() {
  const tbody = document.getElementById("subscribers-tbody");
  const cardsContainer = document.getElementById("subscribers-cards");
  const emptyState = document.getElementById("empty-state");

  // Filter & Search Logic
  const filtered = subscribers.filter((sub) => {
    const status = calculateStatus(sub.endDate);

    // Status filter tab
    if (currentFilter !== "all" && status.type !== currentFilter) {
      return false;
    }

    // Search query match
    if (searchQuery.trim() !== "") {
      const q = searchQuery.toLowerCase().trim();
      const matchName = sub.fullName && sub.fullName.toLowerCase().includes(q);
      const matchPhone = sub.phone && sub.phone.toLowerCase().includes(q);
      const matchPlan = sub.plan && sub.plan.toLowerCase().includes(q);
      if (!matchName && !matchPhone && !matchPlan) return false;
    }

    return true;
  });

  if (filtered.length === 0) {
    if (tbody) tbody.innerHTML = "";
    if (cardsContainer) cardsContainer.innerHTML = "";
    if (emptyState) emptyState.classList.remove("hidden");
    return;
  }

  if (emptyState) emptyState.classList.add("hidden");

  // Desktop Table HTML
  let tableHtml = "";
  // Mobile Cards HTML
  let cardsHtml = "";

  filtered.forEach((sub) => {
    const status = calculateStatus(sub.endDate);
    const avatarHtml = getAvatarHtml(sub);

    // Desktop Row
    tableHtml += `
      <tr class="transition hover:bg-gray-800/40">
        <!-- Photo -->
        <td class="w-14">
          ${avatarHtml}
        </td>

        <!-- Full Name -->
        <td>
          <div class="font-bold text-white text-base">${escapeHtml(sub.fullName)}</div>
          <div class="text-xs text-amber-400 font-mono">${escapeHtml(sub.price || "")}</div>
        </td>

        <!-- Phone -->
        <td class="font-mono text-gray-300 text-sm">
          ${sub.phone ? `<i class="fa-solid fa-phone text-xs text-gray-500 me-1"></i> ${escapeHtml(sub.phone)}` : '<span class="text-gray-600">-</span>'}
        </td>

        <!-- Plan -->
        <td>
          <span class="text-xs px-2.5 py-1 rounded-md bg-gray-800 text-gray-300 border border-gray-700">
            ${escapeHtml(sub.plan || "اشتراك شهري")}
          </span>
        </td>

        <!-- Start Date -->
        <td class="font-mono text-gray-300 text-sm">
          <i class="fa-regular fa-calendar-check text-xs text-emerald-400 me-1"></i>
          ${formatDate(sub.startDate)}
        </td>

        <!-- End Date -->
        <td class="font-mono text-white font-semibold text-sm">
          <i class="fa-regular fa-calendar-xmark text-xs text-amber-400 me-1"></i>
          ${formatDate(sub.endDate)}
        </td>

        <!-- Days Remaining -->
        <td>
          <span class="font-semibold text-xs" style="color: ${status.color}">
            ${status.daysText}
          </span>
        </td>

        <!-- Status Badge -->
        <td>
          <span class="badge ${status.badgeClass}">
            ${status.label}
          </span>
        </td>

        <!-- Actions -->
        <td>
          <div class="flex items-center justify-center gap-1.5">
            <!-- Renew Button (+30 days) -->
            <button onclick="renewSubscriber('${sub.id}')" class="btn btn-action-renew" title="${t('btnRenew')}">
              <i class="fa-solid fa-arrows-rotate"></i>
              <span class="text-xs font-bold">+30j</span>
            </button>
            <!-- Edit Button -->
            <button onclick="openEditModal('${sub.id}')" class="btn btn-action-edit" title="${t('btnEdit')}">
              <i class="fa-solid fa-pen-to-square"></i>
            </button>
            <!-- Delete Button -->
            <button onclick="openDeleteModal('${sub.id}', '${escapeHtml(sub.fullName)}')" class="btn btn-action-delete" title="${t('btnDelete')}">
              <i class="fa-solid fa-trash-can"></i>
            </button>
          </div>
        </td>
      </tr>
    `;

    // Mobile Card
    cardsHtml += `
      <div class="member-card-mobile">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-3">
            ${avatarHtml}
            <div>
              <h4 class="font-bold text-white text-base">${escapeHtml(sub.fullName)}</h4>
              <p class="text-xs text-gray-400 font-mono">${sub.phone || ""}</p>
            </div>
          </div>
          <span class="badge ${status.badgeClass}">
            ${status.label}
          </span>
        </div>

        <div class="grid grid-cols-2 gap-2 text-xs bg-gray-900/60 p-2.5 rounded-lg border border-gray-800">
          <div>
            <span class="text-gray-400 block">${t("thStartDate")}:</span>
            <span class="font-mono text-gray-200">${formatDate(sub.startDate)}</span>
          </div>
          <div>
            <span class="text-gray-400 block">${t("thEndDate")}:</span>
            <span class="font-mono font-bold text-amber-400">${formatDate(sub.endDate)}</span>
          </div>
          <div class="col-span-2 pt-1 border-t border-gray-800 flex items-center justify-between">
            <span class="text-gray-400">${t("thDaysLeft")}:</span>
            <span class="font-bold" style="color: ${status.color}">${status.daysText}</span>
          </div>
        </div>

        <div class="flex items-center gap-2 pt-1">
          <button onclick="renewSubscriber('${sub.id}')" class="btn btn-action-renew flex-1 text-xs py-2">
            <i class="fa-solid fa-arrows-rotate"></i> ${t("btnRenew")}
          </button>
          <button onclick="openEditModal('${sub.id}')" class="btn btn-action-edit px-3 py-2 text-xs">
            <i class="fa-solid fa-pen-to-square"></i>
          </button>
          <button onclick="openDeleteModal('${sub.id}', '${escapeHtml(sub.fullName)}')" class="btn btn-action-delete px-3 py-2 text-xs">
            <i class="fa-solid fa-trash-can"></i>
          </button>
        </div>
      </div>
    `;
  });

  if (tbody) tbody.innerHTML = tableHtml;
  if (cardsContainer) cardsContainer.innerHTML = cardsHtml;
}

function getAvatarHtml(sub) {
  if (sub.photo && sub.photo.trim() !== "") {
    return `<img src="${sub.photo}" alt="${escapeHtml(sub.fullName)}" class="member-avatar" onerror="this.outerHTML='<div class=\\'member-avatar\\'><i class=\\'fa-solid fa-user text-amber-400\\'></i></div>'">`;
  }
  const initial = sub.fullName ? sub.fullName.trim().charAt(0).toUpperCase() : "M";
  return `<div class="member-avatar"><span class="avatar-initials">${initial}</span></div>`;
}

// --------------------------------------------------------------------------
// 6. Stats Overview Update
// --------------------------------------------------------------------------
function updateStats() {
  let total = subscribers.length;
  let active = 0;
  let expiring = 0;
  let expired = 0;

  subscribers.forEach((sub) => {
    const st = calculateStatus(sub.endDate);
    if (st.type === "active") active++;
    else if (st.type === "expiring") expiring++;
    else if (st.type === "expired") expired++;
  });

  const totalEl = document.getElementById("stat-total");
  const activeEl = document.getElementById("stat-active");
  const expiringEl = document.getElementById("stat-expiring");
  const expiredEl = document.getElementById("stat-expired");

  if (totalEl) totalEl.textContent = total;
  if (activeEl) activeEl.textContent = active;
  if (expiringEl) expiringEl.textContent = expiring;
  if (expiredEl) expiredEl.textContent = expired;
}

// --------------------------------------------------------------------------
// 7. Search & Filter Handling
// --------------------------------------------------------------------------
function handleSearch(val) {
  searchQuery = val;
  const clearBtn = document.getElementById("search-clear");
  if (clearBtn) {
    if (val && val.length > 0) clearBtn.classList.remove("hidden");
    else clearBtn.classList.add("hidden");
  }
  renderSubscribers();
}

function clearSearch() {
  const searchInput = document.getElementById("search-input");
  if (searchInput) searchInput.value = "";
  searchQuery = "";
  document.getElementById("search-clear").classList.add("hidden");
  renderSubscribers();
}

function setFilter(type) {
  currentFilter = type;
  document.querySelectorAll(".filter-pill").forEach((pill) => pill.classList.remove("active"));
  const activePill = document.getElementById(`filter-${type}`);
  if (activePill) activePill.classList.add("active");
  renderSubscribers();
}

// --------------------------------------------------------------------------
// 8. Add & Edit Modal System
// --------------------------------------------------------------------------
function openAddModal() {
  resetModalForm();
  document.getElementById("modal-title").textContent = t("modalTitleAdd");
  document.getElementById("modal-submit-text").textContent = t("btnSave");
  
  // Default start date = Today (YYYY-MM-DD)
  const todayStr = new Date().toISOString().split("T")[0];
  document.getElementById("modal-startDate").value = todayStr;
  
  // Automatically calculate end date = Today + 30 days
  document.getElementById("modal-endDate").value = addDays(todayStr, 30);

  const modal = document.getElementById("subscriber-modal");
  modal.classList.add("active");
  document.getElementById("modal-fullName").focus();
}

function openEditModal(id) {
  const sub = subscribers.find((s) => s.id === id);
  if (!sub) return;

  resetModalForm();
  document.getElementById("modal-title").textContent = t("modalTitleEdit");
  document.getElementById("modal-submit-text").textContent = t("btnSave");
  document.getElementById("subscriber-id").value = sub.id;

  document.getElementById("modal-fullName").value = sub.fullName || "";
  document.getElementById("modal-phone").value = sub.phone || "";
  document.getElementById("modal-plan").value = sub.plan || "كمال أجسام + لياقة (Bodybuilding & Fitness)";
  document.getElementById("modal-startDate").value = sub.startDate || "";
  document.getElementById("modal-endDate").value = sub.endDate || "";

  // If has existing photo
  if (sub.photo) {
    showPhotoPreview(sub.photo);
  }

  const modal = document.getElementById("subscriber-modal");
  modal.classList.add("active");
}

function closeModal() {
  const modal = document.getElementById("subscriber-modal");
  modal.classList.remove("active");
  resetModalForm();
}

function resetModalForm() {
  document.getElementById("subscriber-form").reset();
  document.getElementById("subscriber-id").value = "";
  clearPhotoPreview();
}

// Reactively compute 30 days when Start Date is changed
function handleStartDateChange(startDateVal) {
  if (startDateVal) {
    const autoEndDate = addDays(startDateVal, 30);
    document.getElementById("modal-endDate").value = autoEndDate;
  }
}

// --------------------------------------------------------------------------
// 9. Photo Drag & Drop & Live Preview
// --------------------------------------------------------------------------
function initDragAndDrop() {
  const dropZone = document.getElementById("drop-zone");
  if (!dropZone) return;

  ["dragenter", "dragover"].forEach((eventName) => {
    dropZone.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropZone.classList.add("dragover");
    });
  });

  ["dragleave", "drop"].forEach((eventName) => {
    dropZone.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropZone.classList.remove("dragover");
    });
  });

  dropZone.addEventListener("drop", (e) => {
    const dt = e.dataTransfer;
    const files = dt.files;
    if (files && files[0] && files[0].type.startsWith("image/")) {
      handlePhotoFile(files[0]);
    }
  });
}

function handlePhotoSelect(input) {
  if (input.files && input.files[0]) {
    handlePhotoFile(input.files[0]);
  }
}

function handlePhotoFile(file) {
  selectedPhotoFile = file;
  const reader = new FileReader();
  reader.onload = (e) => {
    showPhotoPreview(e.target.result);
  };
  reader.readAsDataURL(file);
}

function showPhotoPreview(imgSrc) {
  const uploadPrompt = document.getElementById("upload-prompt");
  const previewSection = document.getElementById("preview-section");
  const avatarImg = document.getElementById("avatar-preview-img");

  if (uploadPrompt) uploadPrompt.classList.add("hidden");
  if (previewSection) previewSection.classList.remove("hidden");
  if (avatarImg) avatarImg.src = imgSrc;
}

function clearPhotoPreview() {
  selectedPhotoFile = null;
  const photoInput = document.getElementById("photo-input");
  if (photoInput) photoInput.value = "";

  const uploadPrompt = document.getElementById("upload-prompt");
  const previewSection = document.getElementById("preview-section");
  const avatarImg = document.getElementById("avatar-preview-img");

  if (uploadPrompt) uploadPrompt.classList.remove("hidden");
  if (previewSection) previewSection.classList.add("hidden");
  if (avatarImg) avatarImg.src = "";
}

// --------------------------------------------------------------------------
// 10. Form Submission (Add / Edit API)
// --------------------------------------------------------------------------
async function handleFormSubmit(e) {
  e.preventDefault();

  const id = document.getElementById("subscriber-id").value;
  const fullName = document.getElementById("modal-fullName").value;
  const phone = document.getElementById("modal-phone").value;
  const plan = document.getElementById("modal-plan").value;
  const startDate = document.getElementById("modal-startDate").value;
  const endDate = document.getElementById("modal-endDate").value;

  if (!fullName.trim() || !startDate || !endDate) {
    alert("يرجى ملء الحقول المطلوبة");
    return;
  }

  const submitBtn = document.getElementById("modal-submit-btn");
  submitBtn.disabled = true;
  document.getElementById("modal-submit-text").textContent = t("btnSaving");

  const formData = new FormData();
  formData.append("fullName", fullName);
  formData.append("phone", phone);
  formData.append("plan", plan);
  formData.append("startDate", startDate);
  formData.append("endDate", endDate);

  if (selectedPhotoFile) {
    formData.append("photo", selectedPhotoFile);
  }

  try {
    let url = "/api/subscribers";
    let method = "POST";

    if (id) {
      url = `/api/subscribers/${id}`;
      method = "PUT";
    }

    const res = await fetch(url, {
      method: method,
      body: formData,
    });

    const json = await res.json();
    if (json.success) {
      closeModal();
      showToast(id ? t("toastUpdated") : t("toastAdded"), "success");
      loadSubscribers(false);
    } else {
      showToast(json.message || t("toastError"), "error");
    }
  } catch (err) {
    console.error("Form submit error:", err);
    showToast(t("toastError"), "error");
  } finally {
    submitBtn.disabled = false;
    document.getElementById("modal-submit-text").textContent = t("btnSave");
  }
}

// --------------------------------------------------------------------------
// 11. Subscription Renewal (+30 Days)
// --------------------------------------------------------------------------
async function renewSubscriber(id) {
  try {
    const res = await fetch(`/api/subscribers/${id}/renew`, { method: "POST" });
    const json = await res.json();
    if (json.success) {
      showToast(t("toastRenewed"), "success");
      loadSubscribers(false);
    } else {
      showToast(json.message || t("toastError"), "error");
    }
  } catch (err) {
    console.error("Renew error:", err);
    showToast(t("toastError"), "error");
  }
}

// --------------------------------------------------------------------------
// 12. Delete Subscriber Confirmation
// --------------------------------------------------------------------------
function openDeleteModal(id, memberName) {
  deleteTargetId = id;
  const nameEl = document.getElementById("delete-member-name");
  if (nameEl) nameEl.textContent = memberName;
  const modal = document.getElementById("delete-modal");
  modal.classList.add("active");
}

function closeDeleteModal() {
  deleteTargetId = null;
  const modal = document.getElementById("delete-modal");
  modal.classList.remove("active");
}

async function executeDelete() {
  if (!deleteTargetId) return;

  const btn = document.getElementById("confirm-delete-btn");
  btn.disabled = true;

  try {
    const res = await fetch(`/api/subscribers/${deleteTargetId}`, { method: "DELETE" });
    const json = await res.json();
    if (json.success) {
      closeDeleteModal();
      showToast(t("toastDeleted"), "info");
      loadSubscribers(false);
    } else {
      showToast(json.message || t("toastError"), "error");
    }
  } catch (err) {
    console.error("Delete error:", err);
    showToast(t("toastError"), "error");
  } finally {
    btn.disabled = false;
  }
}

// --------------------------------------------------------------------------
// 13. Export to CSV (with UTF-8 BOM for Excel)
// --------------------------------------------------------------------------
function exportToCsv() {
  if (subscribers.length === 0) {
    alert("لا توجد بيانات لتصديرها.");
    return;
  }

  let csv = "\uFEFF"; // UTF-8 BOM
  csv += "ID,Full Name,Phone,Plan,Start Date,End Date,Status,Days Remaining\n";

  subscribers.forEach((sub) => {
    const st = calculateStatus(sub.endDate);
    const row = [
      `"${sub.id}"`,
      `"${(sub.fullName || "").replace(/"/g, '""')}"`,
      `"${(sub.phone || "").replace(/"/g, '""')}"`,
      `"${(sub.plan || "").replace(/"/g, '""')}"`,
      `"${sub.startDate}"`,
      `"${sub.endDate}"`,
      `"${st.label}"`,
      `"${st.daysText}"`,
    ];
    csv += row.join(",") + "\n";
  });

  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  const url = URL.createObjectURL(blob);
  link.setAttribute("href", url);
  link.setAttribute("download", `fares_gym_subscribers_${new Date().toISOString().split("T")[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// --------------------------------------------------------------------------
// 14. Toast Notification System
// --------------------------------------------------------------------------
function showToast(message, type = "info") {
  const container = document.getElementById("toast-container");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = "toast";

  let icon = '<i class="fa-solid fa-circle-check text-emerald-400 text-lg"></i>';
  if (type === "error") icon = '<i class="fa-solid fa-triangle-exclamation text-rose-400 text-lg"></i>';
  else if (type === "warning") icon = '<i class="fa-solid fa-circle-exclamation text-amber-400 text-lg"></i>';

  toast.innerHTML = `
    ${icon}
    <div class="text-sm font-medium text-white flex-1">${message}</div>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transition = "opacity 0.4s ease";
    setTimeout(() => toast.remove(), 400);
  }, 4000);
}

// Helper: Escape HTML
function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
