﻿const translations = {
  ar: {
    gymName: "فارس جيم",
    gymTagline: "لوحة تحكم إدارة الاشتراكات الذكية",
    liveConnected: "متصل بالخادم (تزامن فوري)",
    liveDisconnected: "جارٍ إعادة الاتصال...",
    
    // Stats
    statTotal: "إجمالي المشتركين",
    statActive: "اشتراكات نشطة",
    statActiveDesc: "متبقي أكثر من 3 أيام",
    statExpiring: "تنبيه انتهاء قريب",
    statExpiringDesc: "متبقي 3 أيام أو أقل",
    statExpired: "اشتراكات منتهية",
    statExpiredDesc: "تجاوزت تاريخ الانتهاء",

    // Controls
    searchPlaceholder: "ابحث عن مشترك بالاسم أو رقم الهاتف...",
    filterAll: "الكل",
    filterActive: "نشط (أخضر)",
    filterExpiring: "قريب من الانتهاء (أصفر)",
    filterExpired: "منتهي (أحمر)",
    btnAddMember: "إضافة مشترك جديد",
    btnExportCsv: "تصدير القائمة (CSV)",
    btnRefresh: "تحديث",
    
    // Table Headers
    thPhoto: "الصورة",
    thName: "اسم المشترك",
    thPhone: "رقم الهاتف",
    thPlan: "نوع الاشتراك",
    thStartDate: "تاريخ البدء",
    thEndDate: "تاريخ الانتهاء",
    thDaysLeft: "المدة المتبقية",
    thStatus: "الحالة",
    thActions: "الإجراءات",

    // Status Badges
    statusActive: "نشط",
    statusExpiring: "قريب من الانتهاء",
    statusExpired: "منتهي الصلاحية",
    daysRemaining: "{n} يوم متبقي",
    dayRemaining: "يوم واحد متبقي",
    twoDaysRemaining: "يومان متبقيان",
    daysOverdue: "منتهي منذ {n} يوم",
    todayExpires: "ينتهي اليوم!",

    // Actions
    btnRenew: "تجديد (+30 يوم)",
    btnEdit: "تعديل",
    btnDelete: "حذف",
    
    // Modal Add / Edit
    modalTitleAdd: "إضافة مشترك جديد - FARES GYM",
    modalTitleEdit: "تعديل بيانات المشترك",
    labelFullName: "اسم المشترك الكامل *",
    placeholderFullName: "مثال: أمين بن سالم",
    labelPhoto: "صورة المشترك (اختياري)",
    photoDropText: "اسحب الصورة وأفلتها هنا أو اضغط للاختيار",
    photoHint: "يدعم PNG, JPG, WEBP (الحد الأقصى 10MB)",
    photoChange: "تغيير الصورة",
    photoRemove: "حذف الصورة",
    labelPhone: "رقم الهاتف",
    placeholderPhone: "مثال: 0555 12 34 56",
    labelPlan: "نوع الاشتراك",
    planStandard: "اشتراك شهري عادي (Standard)",
    planFitness: "كمال أجسام + لياقة (Bodybuilding & Fitness)",
    planVip: "VIP شامل تدريب خاص (VIP + Coach)",
    planCrossfit: "Crossfit و كمال أجسام",
    labelPrice: "سعر الاشتراك",
    placeholderPrice: "مثال: 3000 دج",
    labelStartDate: "تاريخ بدء الاشتراك *",
    startDateHint: "تلقائياً تاريخ اليوم (يمكنك تعديله)",
    labelEndDate: "تاريخ انتهاء الاشتراك (30 يوماً تلقائياً) *",
    endDateHint: "يُحسب تلقائياً بإضافة 30 يوماً بدقة إلى تاريخ البدء",
    btnSave: "حفظ المشترك",
    btnSaving: "جارٍ الحفظ...",
    btnCancel: "إلغاء",

    // Confirm Delete Modal
    confirmDeleteTitle: "تأكيد حذف المشترك",
    confirmDeleteMsg: "هل أنت متأكد من رغبتك في حذف المشترك: ",
    confirmDeleteWarning: "لن يمكنك استرجاع هذه البيانات بعد الحذف.",
    btnConfirmDelete: "نعم، احذف",

    // Toasts & Notifications
    toastAdded: "تمت إضافة المشترك بنجاح إلى النظام! 🎉",
    toastUpdated: "تم تحديث بيانات المشترك بنجاح! ✏️",
    toastRenewed: "تم تجديد اشتراك المشترك لمدة 30 يوماً إضافية! 🔄",
    toastDeleted: "تم حذف المشترك من النظام بنجاح. 🗑️",
    toastError: "حدث خطأ أثناء معالجة الطلب.",
    noResults: "لم يتم العثور على أي مشتركين يطابقون بحثك.",
    noDataYet: "لا يوجد مشتركون مسجلون حالياً. اضغط على 'إضافة مشترك جديد' للبدء."
  },
  fr: {
    gymName: "FARES GYM",
    gymTagline: "Panneau d'administration intelligent des abonnements",
    liveConnected: "Connecté au serveur (Synchro en direct)",
    liveDisconnected: "Reconnexion en cours...",
    
    // Stats
    statTotal: "Total des Abonnés",
    statActive: "Abonnements Actifs",
    statActiveDesc: "Plus de 3 jours restants",
    statExpiring: "Expire Bientôt",
    statExpiringDesc: "3 jours ou moins restants",
    statExpired: "Abonnements Expirés",
    statExpiredDesc: "Date limite dépassée",

    // Controls
    searchPlaceholder: "Rechercher par nom ou numéro de téléphone...",
    filterAll: "Tous",
    filterActive: "Actifs (Vert)",
    filterExpiring: "Expire bientôt (Jaune)",
    filterExpired: "Expirés (Rouge)",
    btnAddMember: "Ajouter un membre",
    btnExportCsv: "Exporter (CSV)",
    btnRefresh: "Actualiser",
    
    // Table Headers
    thPhoto: "Photo",
    thName: "Nom Complet",
    thPhone: "Téléphone",
    thPlan: "Type d'abonnement",
    thStartDate: "Date Début",
    thEndDate: "Date Fin",
    thDaysLeft: "Jours Restants",
    thStatus: "Statut",
    thActions: "Actions",

    // Status Badges
    statusActive: "Actif",
    statusExpiring: "Expire bientôt",
    statusExpired: "Expiré",
    daysRemaining: "{n} jours restants",
    dayRemaining: "1 jour restant",
    twoDaysRemaining: "2 jours restants",
    daysOverdue: "Expiré depuis {n} j",
    todayExpires: "Expire aujourd'hui !",

    // Actions
    btnRenew: "Renouveler (+30 j)",
    btnEdit: "Modifier",
    btnDelete: "Supprimer",
    
    // Modal Add / Edit
    modalTitleAdd: "Ajouter un nouvel abonné - FARES GYM",
    modalTitleEdit: "Modifier l'abonné",
    labelFullName: "Nom complet de l'abonné *",
    placeholderFullName: "Ex: Amine Ben Salem",
    labelPhoto: "Photo de l'abonné (optionnelle)",
    photoDropText: "Glissez et déposez l'image ici ou cliquez pour choisir",
    photoHint: "Prend en charge PNG, JPG, WEBP (Max 10 Mo)",
    photoChange: "Changer la photo",
    photoRemove: "Supprimer la photo",
    labelPhone: "Numéro de téléphone",
    placeholderPhone: "Ex: 0555 12 34 56",
    labelPlan: "Type d'abonnement",
    planStandard: "Abonnement Standard Mensuel",
    planFitness: "Musculation + Fitness",
    planVip: "VIP avec Coach Personnel",
    planCrossfit: "Crossfit & Musculation",
    labelPrice: "Tarif",
    placeholderPrice: "Ex: 3000 DZD",
    labelStartDate: "Date de début d'abonnement *",
    startDateHint: "Date du jour par défaut (modifiable)",
    labelEndDate: "Date de fin (30 jours auto) *",
    endDateHint: "Calculée automatiquement en ajoutant 30 jours à la date de début",
    btnSave: "Enregistrer l'abonné",
    btnSaving: "Enregistrement...",
    btnCancel: "Annuler",

    // Confirm Delete Modal
    confirmDeleteTitle: "Confirmer la suppression",
    confirmDeleteMsg: "Êtes-vous sûr de vouloir supprimer l'abonné : ",
    confirmDeleteWarning: "Cette action est irréversible.",
    btnConfirmDelete: "Oui, Supprimer",

    // Toasts & Notifications
    toastAdded: "Abonné ajouté avec succès au système ! 🎉",
    toastUpdated: "Données de l'abonné mises à jour avec succès ! ✏️",
    toastRenewed: "Abonnement renouvelé pour 30 jours supplémentaires ! 🔄",
    toastDeleted: "Abonné supprimé avec succès. 🗑️",
    toastError: "Une erreur est survenue lors du traitement.",
    noResults: "Aucun abonné ne correspond à votre recherche.",
    noDataYet: "Aucun abonné enregistré pour le moment. Cliquez sur 'Ajouter un membre' pour commencer."
  }
};
