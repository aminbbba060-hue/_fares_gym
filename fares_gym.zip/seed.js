﻿const fs = require("fs");
const path = require("path");

const dbPath = path.join(__dirname, "data", "subscribers.json");

const initialData = [
  {
    id: "sub_1",
    fullName: "أمين بن سالم (Amine Ben Salem)",
    phone: "0555 12 34 56",
    plan: "كمال أجسام + لياقة (Bodybuilding & Fitness)",
    price: "3000 DZD",
    photo: "/uploads/demo1.svg",
    startDate: "2026-10-01",
    endDate: "2026-10-31",
    createdAt: "2026-10-01T10:00:00.000Z"
  },
  {
    id: "sub_2",
    fullName: "كريم بلقاسم (Karim Belkacem)",
    phone: "0661 78 90 12",
    plan: "اشتراك شهري عادي (Standard)",
    price: "2500 DZD",
    photo: "/uploads/demo2.svg",
    startDate: "2026-09-10",
    endDate: "2026-10-10",
    createdAt: "2026-09-10T14:30:00.000Z"
  },
  {
    id: "sub_3",
    fullName: "ياسين عماري (Yacine Ammari)",
    phone: "0770 44 55 66",
    plan: "VIP شامل تدريب خاص (VIP + Coach)",
    price: "6000 DZD",
    photo: "/uploads/demo3.svg",
    startDate: "2026-09-01",
    endDate: "2026-10-01",
    createdAt: "2026-09-01T09:15:00.000Z"
  },
  {
    id: "sub_4",
    fullName: "رياض محرز (Riyad Mahrez)",
    phone: "0550 99 88 77",
    plan: "لياقة بدنية و Crossfit",
    price: "3500 DZD",
    photo: "",
    startDate: "2026-10-08",
    endDate: "2026-11-07",
    createdAt: "2026-10-08T11:00:00.000Z"
  }
];

fs.writeFileSync(dbPath, JSON.stringify(initialData, null, 2), "utf-8");
console.log("Database seeded successfully with Arabic text preserved.");
