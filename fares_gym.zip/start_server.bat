@echo off
title FARES GYM - Admin Panel Server
echo ===================================================
echo     FARES GYM - Starting Server
echo ===================================================
echo Local: http://localhost:3000
echo Network (Phones/Laptops): http://10.60.2.148:3000
echo ===================================================
cd /d "%~dp0"
node server.js
pause
